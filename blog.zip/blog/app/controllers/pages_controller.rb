class PagesController < ApplicationController
	
	def about
	end

end
